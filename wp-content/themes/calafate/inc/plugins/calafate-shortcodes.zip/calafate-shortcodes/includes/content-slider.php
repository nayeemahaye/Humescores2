<?php

if ( ! function_exists( 'calafate_content_slider_shortcode' ) ) :

	function calafate_content_slider_shortcode( $attr, $content ) {
		$output = '<div class="carousel calafate-slider">' . do_shortcode( $content ) . '</div>';
		return $output;
	}

endif;

add_shortcode( 'calafate_content_slider', 'calafate_content_slider_shortcode' );

if ( ! function_exists( 'calafate_content_slide_shortcode' ) ) :

	function calafate_content_slide_shortcode( $attr, $content ) {
		$output = '<div class="carousel-cell">' . do_shortcode( $content ) . '</div>';
		return $output;
	}

endif;

add_shortcode( 'calafate_content_slide', 'calafate_content_slide_shortcode' );