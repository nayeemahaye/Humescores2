<?php

if ( ! function_exists( 'calafate_toggle_shortcode' ) ) :

	function calafate_toggle_shortcode( $attr, $content ) {
		$output = '<div class="calafate-toggle"><h5>' . $attr['title'] . '</h5><div class="content">' . do_shortcode( $content ) . '</div></div>';
		return $output;
	}

endif;

add_shortcode( 'calafate_toggle', 'calafate_toggle_shortcode' );
