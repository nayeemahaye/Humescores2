<?php

/*
Plugin Name: Calafate Shortcodes
Description: A simple set of shortcodes for the Calafate Theme
Version: 0.3
Author: Ruben Bristian
Author URI: http://rubenbristian.com
License: GPL
License URI: http://www.gnu.org/copyleft/gpl.html
*/

class CalafateShortcodes {

    function __construct() {  

        $current_theme = wp_get_theme();
        
        require_once( plugin_dir_path( __FILE__ ) . 'includes/twitter-slider.php' );
        require_once( plugin_dir_path( __FILE__ ) . 'includes/content-slider.php' );
        require_once( plugin_dir_path( __FILE__ ) . 'includes/toggle.php' );
        require_once( plugin_dir_path( __FILE__ ) . 'includes/gallery.php' );
        
        add_action( 'init', array( &$this, 'init' ) );

    }
    
    function init() {
        
    }
    
}

new CalafateShortcodes();
